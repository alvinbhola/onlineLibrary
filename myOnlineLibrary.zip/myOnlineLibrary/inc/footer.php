</div><!-- end content -->

	<div class="footer">

		<div class="wrapper">

			<ul>
				<li><a href="https://www.instagram.com/LaGuardiaCC/">Twitter</a></li>
				<li><a href="https://www.facebook.com/LaGuardiaCC">Facebook</a></li>
			</ul>

			<p>&copy;<?php echo date("Y"); ?> My Online Library</p>

		</div>

	</div>

</body>
</html>
